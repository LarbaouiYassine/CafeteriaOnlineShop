# Cafeteria-shop

online shop for cafeteria products


1. [`./server-side/`](./server-side/README.md)
2. [`./client-side/`](./client-side/README.md)


### server-side

The `./server-side` directory contains a partially completed server with pre-written modules to simplify your data needs. You will need to complete the required endpoints, configure, and integrate Auth0 for authentication.

[View the README.md within ./server-side for more details.](./server-side/README.md)

### client-side

The `./client-side` directory contains a complete Ionic client-side to exploit the data from the server. You will only need to update the environment variables found within (./client-side/src/environment/environment.ts) to reflect the Auth0 configuration details set up for the server-side app. 

[View the README.md within ./client-sidefor more details.](./client-side/README.md)